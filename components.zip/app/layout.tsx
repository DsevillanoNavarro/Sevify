import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Sevify | Diseño Web Moderno, Minimalista y Funcional",
  description:
    "Sevify crea experiencias digitales con diseño web minimalista, interfaces intuitivas y alto rendimiento. Inspirado en la estética y la usabilidad.",
  keywords: [
    "diseño web moderno",
    "web minimalista",
    "diseño UI UX",
    "experiencia de usuario",
    "Sevify Studio",
    "interfaz digital",
    "frontend",
    "desarrollador web",
    "proyectos de diseño web",
  ],
  authors: [{ name: "Sevify" }],
  creator: "Sevify",
  publisher: "Sevify",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    title: "Sevify | Diseño Web Moderno, Minimalista y Funcional",
    description: "Interfaz limpia. Navegación fluida. Diseño con propósito.",
    url: "https://sevify.com", // O tu dominio real
    siteName: "Sevify",
    locale: "es_ES",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sevify | Diseño Web Moderno y UI/UX",
    description: "Diseño centrado en la estética, el rendimiento y la experiencia de usuario.",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>
        <a href="#main" className="skip-link">
          Saltar al contenido principal
        </a>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
