import type { Metadata } from "next"

// Cargar componentes críticos inmediatamente
import { Hero } from "@/components/hero"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { DynamicSections } from "./client-components"

export const metadata: Metadata = {
  title: "Sevify | Diseño Web Moderno, Minimalista y Funcional",
  description:
    "Sevify crea experiencias digitales con diseño web minimalista, interfaces intuitivas y alto rendimiento. Inspirado en la estética y la usabilidad.",
  keywords: [
    "diseño web moderno",
    "web minimalista",
    "diseño UI UX",
    "experiencia de usuario",
    "Sevify Studio",
    "interfaz digital",
    "frontend",
    "desarrollador web",
    "proyectos de diseño web",
  ],
  icons: {
    icon: "./favicon.ico", // ruta relativa en public/
    shortcut: "./favicon.ico", // para navegadores que usan shortcut icon
    apple: "./apple-touch-icon.png", // si tienes icono para iOS
  },
}

export default function Home() {
  return (
    <main id="main" className="flex min-h-screen flex-col items-center justify-between">
      <Header />
      <Hero />
      <DynamicSections />
      <Footer />
    </main>
  )
}
